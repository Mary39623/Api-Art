package com.example.artinstituteapp

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnVoltar = findViewById<Button>(R.id.btn_voltar)
        val btnArts = findViewById<Button>(R.id.btn_get_artworks)
        val imageView = findViewById<ImageView>(R.id.image_view)
        val tvLegenda = findViewById<TextView>(R.id.tv_legenda)

        val api = RetrofitClient.getRetrofit().create(ArtInstituteAPI::class.java)

        btnArts.setOnClickListener {
            api.getArtworks().enqueue(object : Callback<ArtResponse> {
                override fun onResponse(call: Call<ArtResponse>, response: Response<ArtResponse>) {
                    if (response.isSuccessful) {
                        val artworks = response.body()?.data
                        Log.d("ArtAPI", "Total de obras recebidas: ${artworks?.size}")

                        val artwork = artworks?.randomOrNull()
                        artwork?.let {
                            val imageUrl =
                            "https://www.artic.edu/iiif/2/${it.image_id}/full/843,/0/default.jpg"

                            Log.d("ArtAPI", "Imagem aleatória carregada: $imageUrl")

                            Picasso.get()
                                .load(imageUrl)
                                .fit()
                                .centerCrop()
                                .placeholder(R.drawable.placeholder_image)
                                .noFade()
                                .into(imageView, object : com.squareup.picasso.Callback {
                                    override fun onSuccess() {
                                        Log.d("ArtAPI", "Imagem carregada com sucesso")
                                    }

                                    override fun onError(e: Exception?) {
                                        Log.e("ArtAPI", "Erro ao carregar imagem", e)
                                    }
                                })

                            // 🔽 Sempre define legenda fixa
                            tvLegenda.text = "🎭 Arte é a expressão da alma"
                        } ?: Log.w("ArtAPI", "Lista de obras vazia ou nula")
                    } else {
                        Log.e("ArtAPI", "Erro na resposta: ${response.code()} - ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<ArtResponse>, t: Throwable) {
                    Log.e("ArtAPI", "Falha na chamada: ${t.localizedMessage}", t)
                }
            })
        }

        btnVoltar.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }
}
