package com.example.artinstituteapp

data class ArtistResponse(
    val data: List<Artist>
)

data class Artist(
    val id: Int,
    val title: String,
    val artist_display: String,
    val imagem_id: String,
    val thumbnail: Thumbnail
)
