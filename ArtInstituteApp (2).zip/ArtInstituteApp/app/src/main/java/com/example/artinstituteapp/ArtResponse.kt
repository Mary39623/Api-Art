package com.example.artinstituteapp

data class ArtResponse(
    val data: List<Artwork>
)