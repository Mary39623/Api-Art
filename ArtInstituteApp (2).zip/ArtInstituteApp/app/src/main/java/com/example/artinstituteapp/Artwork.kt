package com.example.artinstituteapp

data class Artwork(
    val id: Int,
    val title: String,
    val artist_display: String?,
    val image_id: String?,
    val thumbnail: Thumbnail? // inclui legenda da imagem
)

data class Thumbnail(
    val alt_text: String? // legenda da obra
)

