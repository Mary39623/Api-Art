package com.example.artinstituteapp

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query


interface ArtInstituteAPI {


    @GET("api/v1/artworks")
    fun getArtworks(@Query("page") page: Int = 1): Call<ArtResponse>


    @GET("api/v1/artworks/{id}")
    fun getArtworkById(@Path("id") id: Int): Call<Artwork>


    @GET("api/v1/artists")
    fun getArtists(@Query("page") page: Int = 1): Call<ArtistResponse>
}
